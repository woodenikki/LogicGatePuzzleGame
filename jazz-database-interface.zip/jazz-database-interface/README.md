# jazz-database-interface
An interface for filtering and selecting music from a database.

matt was here
